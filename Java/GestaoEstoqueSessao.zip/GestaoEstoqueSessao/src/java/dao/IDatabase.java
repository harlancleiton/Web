package dao;

public interface IDatabase{
    
    public final String DRIVER="org.apache.derby.jdbc.ClientDriver";
    public final String CAMINHOBANCO="jdbc:derby://localhost:1527/DesenvolvimentoWeb";
    public final String USUARIO="root";
    public final String SENHA="root";
}