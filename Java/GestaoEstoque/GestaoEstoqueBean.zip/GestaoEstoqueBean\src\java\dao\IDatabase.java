/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Aluno
 */
public interface IDatabase {
    public final String DRIVER     = "org.apache.derby.jdbc.ClientDriver";
    public final String CAMINHOBANCO   = "jdbc:derby://localhost:1527/desenvWeb";
    public final String USUARIO      = "root";
    public final String SENHA   = "root";
}
