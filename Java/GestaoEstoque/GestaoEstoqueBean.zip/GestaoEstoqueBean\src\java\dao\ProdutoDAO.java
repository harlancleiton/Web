package dao;

import dto.ProdutoDTO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProdutoDAO {

    private ConexaoBD database = null;
    private PreparedStatement ps;
    private Connection con;
    private ResultSet rs;
    
    public void inserirProduto(ProdutoDTO novoProduto) throws Exception {
        try
        {    //fazendo a conexao
            
             con = database.getConexao();
             //preparando o comando de banco
             ps = con.prepareStatement("insert into MATERIAL (CODIGO,DESCRICAO,PRECO,OBSERVACAO) values (?,?,?,?)");
             //atribuindo valores aos parametros
             ps.setInt(1, novoProduto.getCodigo());
             ps.setString(2, novoProduto.getDescricao());
             ps.setFloat(3, novoProduto.getPreco());
             ps.setString(4, novoProduto.getObservacao());
             
            //executando o comando de banco
             ps.executeUpdate();
             ps.close();
        }
        catch(Exception e)
        {    
            throw new Exception("Nao foi possivel adicionar um novo time. Time ja cadastrado ou houve algum erro. Erro de Sistema: " + e.getMessage());
        }
        finally
        {
            database.fecharConexao();
        }  
    }
    
}