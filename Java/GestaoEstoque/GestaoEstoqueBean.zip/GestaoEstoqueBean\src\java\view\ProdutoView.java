package view;

import bll.ProdutoBLL;
import dto.ProdutoDTO;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ProdutoView {
    
    private int codigo=0;
    private String descricao;
    private String observacao;
    private float preco=0;
    private String acao;
    
    public ProdutoView(){}
    
    public Iterator execute() throws Exception{
        System.out.println("Executando ação adicionar");
        if(this.getAcao()!=null){
            System.out.println("Executando ação adicionar");
            ProdutoBLL produtoBll=new ProdutoBLL();
            if(this.getAcao().equals("Adicionar"))
                produtoBll.inserirProduto(this.novoProduto());
        }
        return null;
    }
    
    private ProdutoDTO novoProduto(){
        ProdutoDTO produto=new ProdutoDTO();
        produto.setCodigo(this.getCodigo());
        produto.setDescricao(this.getDescricao());
        produto.setPreco(this.getPreco());
        produto.setObservacao(this.getObservacao());
        
        return produto;
    }
    
    public void limparDados(){
        System.out.println("Limpando dados");
        this.setAcao("");
        this.setCodigo(0);
        this.setDescricao("");
        this.setPreco(0);
        this.setObservacao("");
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public String getObservacao() {
        return observacao;
    }

    public void setObservacao(String observacao) {
        this.observacao = observacao;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }
    
}